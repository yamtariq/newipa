<div class="sidebar">
    <h3>Welcome, <?php echo $_SESSION['name']; ?></h3>
    <nav>
        <a href="../pages/users.php" class="nav-link">Manage Users</a>
        <a href="../pages/card-applications.php" class="nav-link">Card Applications</a>
        <a href="../pages/loan-applications.php" class="nav-link">Loan Applications</a>
        <a href="../pages/config.php" class="nav-link">System Config</a>
        <a href="../logout.php" class="nav-link">Logout</a>
    </nav>
</div>
