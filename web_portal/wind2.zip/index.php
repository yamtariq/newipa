<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <h3>Welcome, <?php echo $_SESSION['name']; ?></h3>
            <nav>
                <a href="pages/users.php" class="nav-link">Manage Users</a>
                <a href="pages/card-applications.php" class="nav-link">Card Applications</a>
                <a href="pages/loan-applications.php" class="nav-link">Loan Applications</a>
                <a href="pages/config.php" class="nav-link">System Config</a>
                <a href="logout.php" class="nav-link">Logout</a>
            </nav>
        </div>
        <div class="main-content">
            <h2>Dashboard Overview</h2>
            <div class="dashboard-stats">
                <!-- Add dashboard statistics here -->
            </div>
        </div>
    </div>
    <script src="assets/js/main.js"></script>
</body>
</html>
