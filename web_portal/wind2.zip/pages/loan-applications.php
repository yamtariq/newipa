<?php
session_start();
require_once '../db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Fetch loan applications
$query = "SELECT * FROM loan_application_details ORDER BY status_date DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Loan Applications</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="dashboard">
        <?php include '../includes/sidebar.php'; ?>
        <div class="main-content">
            <h2>Loan Applications</h2>
            <div class="search-bar">
                <input type="text" id="search" placeholder="Search by National ID...">
                <select id="statusFilter">
                    <option value="">All Status</option>
                    <option value="pending">Pending</option>
                    <option value="approved">Approved</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Loan ID</th>
                        <th>National ID</th>
                        <th>Amount</th>
                        <th>Purpose</th>
                        <th>Tenure</th>
                        <th>Interest Rate</th>
                        <th>Status</th>
                        <th>Status Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['loan_id']; ?></td>
                        <td><?php echo $row['national_id']; ?></td>
                        <td><?php echo $row['loan_amount']; ?></td>
                        <td><?php echo $row['loan_purpose']; ?></td>
                        <td><?php echo $row['loan_tenure']; ?></td>
                        <td><?php echo $row['interest_rate']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['status_date']; ?></td>
                        <td>
                            <button class="btn btn-primary" onclick="viewDetails(<?php echo $row['loan_id']; ?>, 'loan')">View</button>
                            <?php if ($row['status'] === 'pending'): ?>
                            <button class="btn btn-success" onclick="handleStatusUpdate(<?php echo $row['loan_id']; ?>, 'approved', 'loan')">Approve</button>
                            <button class="btn btn-danger" onclick="handleStatusUpdate(<?php echo $row['loan_id']; ?>, 'rejected', 'loan')">Reject</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php include '../includes/details-modal.php'; ?>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>
