// Mock data matching database schema
let mockData = {
    users: [
        {
            user_id: 1,
            national_id: "1234567890",
            name: "John Doe",
            arabic_name: "جون دو",
            email: "john@example.com",
            phone: "1234567890",
            created_at: "2024-01-20",
            dob: "1990-01-01",
            doe: "2025-01-01",
            finPurpose: "LOAN",
            language: 1,
            productType: 1,
            finAmount: 50000,
            tenure: 12,
            propertyStatus: "O",
            effRate: 5.5,
            ibanNo: "SA0380000000608010167519",
            dependents: 2,
            salary: 15000.00,
            employment_status: "Employed",
            employer_name: "Tech Corp",
            employment_date: "2020-01-01",
            national_address: "123 Main St"
        }
    ],
    cardApplications: [
        {
            card_id: 1,
            national_id: "1234567890",
            card_type: "Gold",
            card_limit: 50000.00,
            status: "pending",
            status_date: "2024-01-20 10:00:00",
            remarks: "Under review"
        }
    ],
    loanApplications: [
        {
            loan_id: 1,
            national_id: "1234567890",
            loan_amount: 100000.00,
            loan_purpose: "Home",
            loan_tenure: 60,
            interest_rate: 5.75,
            status: "pending",
            status_date: "2024-01-20 10:00:00",
            remarks: "Pending approval"
        }
    ],
    config: [
        {
            config_id: 1,
            page: "cards",
            key_name: "maxLimit",
            value: "100000",
            last_updated: "2024-01-20 10:00:00"
        }
    ]
};

// Rest of the navigation code remains the same...

// Users
function loadUsers() {
    const tbody = document.getElementById('usersTableBody');
    tbody.innerHTML = '';
    
    mockData.users.forEach(user => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${user.user_id}</td>
            <td>${user.name}</td>
            <td>${user.arabic_name}</td>
            <td>${user.email}</td>
            <td>${user.phone}</td>
            <td>${user.employment_status}</td>
            <td>
                <button onclick="editUser(${user.user_id})" class="btn-primary">Edit</button>
                <button onclick="deleteUser(${user.user_id})" class="btn-primary">Delete</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Card Applications
function loadCardApplications() {
    const tbody = document.getElementById('cardsTableBody');
    tbody.innerHTML = '';
    
    mockData.cardApplications.forEach(app => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${app.card_id}</td>
            <td>${app.national_id}</td>
            <td>${app.card_type}</td>
            <td>${app.card_limit.toLocaleString()}</td>
            <td>${app.status}</td>
            <td>${app.status_date}</td>
            <td>
                <button onclick="viewCardApplication(${app.card_id})" class="btn-primary">View</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Loan Applications
function loadLoanApplications() {
    const tbody = document.getElementById('loansTableBody');
    tbody.innerHTML = '';
    
    mockData.loanApplications.forEach(app => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${app.loan_id}</td>
            <td>${app.national_id}</td>
            <td>${app.loan_amount.toLocaleString()}</td>
            <td>${app.loan_purpose}</td>
            <td>${app.loan_tenure}</td>
            <td>${app.interest_rate}%</td>
            <td>${app.status}</td>
            <td>${app.status_date}</td>
            <td>
                <button onclick="viewLoanApplication(${app.loan_id})" class="btn-primary">View</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}