<?php
session_start();
require_once 'config/config.php';
require_once 'includes/auth.php';

logout(); // This will handle the session destruction and redirection
?>
