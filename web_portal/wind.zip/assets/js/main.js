// Main JavaScript file for the portal

// Handle sidebar toggle for mobile devices
document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
});

// Handle form submissions with AJAX
function handleFormSubmit(formId, endpoint) {
    const form = document.getElementById(formId);
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(form);
            
            fetch(endpoint, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert('success', data.message);
                    if (data.redirect) {
                        window.location.href = data.redirect;
                    }
                } else {
                    showAlert('danger', data.message);
                }
            })
            .catch(error => {
                showAlert('danger', 'An error occurred. Please try again.');
                console.error('Error:', error);
            });
        });
    }
}

// Show alert messages
function showAlert(type, message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    const container = document.querySelector('.main-content');
    container.insertBefore(alertDiv, container.firstChild);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// Handle data table filtering and sorting
function initializeDataTable(tableId) {
    const table = document.getElementById(tableId);
    if (table) {
        const searchInput = document.querySelector(`#${tableId}-search`);
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const rows = table.querySelectorAll('tbody tr');
                
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(searchTerm) ? '' : 'none';
                });
            });
        }
    }
}

// Handle file uploads
function handleFileUpload(inputId, endpoint) {
    const input = document.getElementById(inputId);
    if (input) {
        input.addEventListener('change', function() {
            const file = this.files[0];
            const formData = new FormData();
            formData.append('file', file);
            
            fetch(endpoint, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert('success', 'File uploaded successfully');
                } else {
                    showAlert('danger', data.message);
                }
            })
            .catch(error => {
                showAlert('danger', 'Error uploading file');
                console.error('Error:', error);
            });
        });
    }
}

// Handle dynamic form validation
function validateForm(formId, rules) {
    const form = document.getElementById(formId);
    if (form) {
        form.addEventListener('submit', function(e) {
            let isValid = true;
            
            Object.keys(rules).forEach(fieldName => {
                const field = form.querySelector(`[name="${fieldName}"]`);
                if (field) {
                    const value = field.value;
                    const fieldRules = rules[fieldName];
                    
                    if (fieldRules.required && !value) {
                        isValid = false;
                        showFieldError(field, 'This field is required');
                    } else if (fieldRules.pattern && !fieldRules.pattern.test(value)) {
                        isValid = false;
                        showFieldError(field, fieldRules.message);
                    }
                }
            });
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
}

// Show field-level validation errors
function showFieldError(field, message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    
    const parent = field.parentElement;
    const existing = parent.querySelector('.field-error');
    if (existing) {
        existing.remove();
    }
    
    parent.appendChild(errorDiv);
}
