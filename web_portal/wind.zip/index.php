<?php
session_start();
require_once 'config/config.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['employee_id'])) {
    header('Location: login.php');
    exit();
}

// Get user role
$userRole = '';
try {
    $stmt = $conn->prepare("SELECT role FROM portal_roles WHERE employee_id = :employee_id");
    $stmt->execute(['employee_id' => $_SESSION['employee_id']]);
    $userRole = $stmt->fetchColumn();
} catch(PDOException $e) {
    error_log("Role fetch error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nayifat Admin Portal</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php include 'includes/header.php'; ?>
        <div class="main-content">
            <?php
            $page = $_GET['page'] ?? 'dashboard';
            $allowedPages = [
                'dashboard', 'users', 'card-applications', 
                'loan-applications', 'config'
            ];
            
            if (in_array($page, $allowedPages)) {
                include "pages/{$page}.php";
            } else {
                include "pages/dashboard.php";
            }
            ?>
        </div>
        <?php include 'includes/footer.php'; ?>
    </div>
    <script src="assets/js/main.js"></script>
</body>
</html>
