<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'icredept_tariq');
define('DB_PASS', 'tariq');
define('DB_NAME', 'icredept_nayifat_app');

// Establish database connection
try {
    $conn = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
        DB_USER,
        DB_PASS,
        array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'")
    );
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    error_log("Connection Error: " . $e->getMessage());
    exit();
}

// Define user roles
define('ROLE_SUPER_ADMIN', 'super_admin');
define('ROLE_SALES_ADMIN', 'sales_admin');
define('ROLE_CREDIT_ADMIN', 'credit_admin');
define('ROLE_CONFIG_ADMIN', 'config_admin');

// Application settings
define('APP_NAME', 'Nayifat Admin Portal');
define('APP_URL', 'https://icreditdept.com/api/portal/');
?>
