<footer class="footer">
    <div class="footer-content">
        <p>&copy; <?php echo date('Y'); ?> Nayifat Admin Portal. All rights reserved.</p>
    </div>
</footer>
