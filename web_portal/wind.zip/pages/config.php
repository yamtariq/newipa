<?php
if (!checkPermission('config_admin') && !checkPermission('super_admin')) {
    header('Location: index.php');
    exit();
}

// Handle configuration updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stmt = $conn->prepare("
            UPDATE master_config 
            SET value = :value 
            WHERE config_id = :config_id
        ");
        
        $stmt->execute([
            'value' => $_POST['value'],
            'config_id' => $_POST['config_id']
        ]);
        
        $success = "Configuration updated successfully";
    } catch(PDOException $e) {
        $error = "Error updating configuration: " . $e->getMessage();
    }
}

// Fetch configurations grouped by page
try {
    $stmt = $conn->query("
        SELECT * FROM master_config 
        ORDER BY page, key_name
    ");
    $configs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Group configurations by page
    $groupedConfigs = [];
    foreach ($configs as $config) {
        $groupedConfigs[$config['page']][] = $config;
    }
} catch(PDOException $e) {
    $error = "Error fetching configurations: " . $e->getMessage();
    $groupedConfigs = [];
}
?>

<div class="config-page">
    <h1>System Configuration</h1>
    
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <?php foreach ($groupedConfigs as $page => $pageConfigs): ?>
        <div class="card mt-20">
            <h3><?php echo ucfirst(htmlspecialchars($page)); ?> Settings</h3>
            <div class="config-grid">
                <?php foreach ($pageConfigs as $config): ?>
                    <div class="config-item">
                        <form method="POST" class="config-form">
                            <input type="hidden" name="config_id" value="<?php echo $config['config_id']; ?>">
                            
                            <div class="form-group">
                                <label for="config_<?php echo $config['config_id']; ?>">
                                    <?php echo htmlspecialchars($config['key_name']); ?>
                                </label>
                                
                                <?php if (strlen($config['value']) > 100): ?>
                                    <textarea id="config_<?php echo $config['config_id']; ?>" 
                                            name="value" class="form-control" rows="4"
                                    ><?php echo htmlspecialchars($config['value']); ?></textarea>
                                <?php else: ?>
                                    <input type="text" id="config_<?php echo $config['config_id']; ?>" 
                                           name="value" class="form-control"
                                           value="<?php echo htmlspecialchars($config['value']); ?>">
                                <?php endif; ?>
                                
                                <div class="config-meta">
                                    Last updated: 
                                    <?php echo date('Y-m-d H:i', strtotime($config['last_updated'])); ?>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-sm">Update</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<style>
.config-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    padding: 20px;
}

.config-item {
    background-color: #f8f9fa;
    padding: 15px;
    border-radius: 4px;
}

.config-form {
    display: grid;
    gap: 10px;
}

.config-meta {
    font-size: 12px;
    color: #666;
    margin-top: 5px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.form-control {
    width: 100%;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-resize textareas
    const textareas = document.querySelectorAll('textarea');
    textareas.forEach(textarea => {
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
        
        // Initial resize
        textarea.dispatchEvent(new Event('input'));
    });
    
    // Confirm before updating
    const forms = document.querySelectorAll('.config-form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!confirm('Are you sure you want to update this configuration?')) {
                e.preventDefault();
            }
        });
    });
});
</script>
