<?php
if (!checkPermission('super_admin')) {
    header('Location: index.php');
    exit();
}

// Handle user actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch($action) {
        case 'add':
            try {
                $stmt = $conn->prepare("
                    INSERT INTO Users (national_id, name, arabic_name, email, password, phone, 
                    created_at, dob, doe, finPurpose, language, productType, finAmount, 
                    tenure, propertyStatus, effRate, ibanNo, dependents, salary, 
                    employment_status, employer_name, employment_date, national_address)
                    VALUES (:national_id, :name, :arabic_name, :email, :password, :phone,
                    NOW(), :dob, :doe, :finPurpose, :language, :productType, :finAmount,
                    :tenure, :propertyStatus, :effRate, :ibanNo, :dependents, :salary,
                    :employment_status, :employer_name, :employment_date, :national_address)
                ");
                
                $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $stmt->execute([
                    'national_id' => $_POST['national_id'],
                    'name' => $_POST['name'],
                    'arabic_name' => $_POST['arabic_name'],
                    'email' => $_POST['email'],
                    'password' => $password,
                    'phone' => $_POST['phone'],
                    'dob' => $_POST['dob'],
                    'doe' => $_POST['doe'],
                    'finPurpose' => $_POST['finPurpose'],
                    'language' => $_POST['language'],
                    'productType' => $_POST['productType'],
                    'finAmount' => $_POST['finAmount'],
                    'tenure' => $_POST['tenure'],
                    'propertyStatus' => $_POST['propertyStatus'],
                    'effRate' => $_POST['effRate'],
                    'ibanNo' => $_POST['ibanNo'],
                    'dependents' => $_POST['dependents'],
                    'salary' => $_POST['salary'],
                    'employment_status' => $_POST['employment_status'],
                    'employer_name' => $_POST['employer_name'],
                    'employment_date' => $_POST['employment_date'],
                    'national_address' => $_POST['national_address']
                ]);
                $success = "User added successfully";
            } catch(PDOException $e) {
                $error = "Error adding user: " . $e->getMessage();
            }
            break;
            
        case 'edit':
            try {
                $stmt = $conn->prepare("
                    UPDATE Users SET 
                    name = :name,
                    arabic_name = :arabic_name,
                    email = :email,
                    phone = :phone,
                    dob = :dob,
                    doe = :doe,
                    finPurpose = :finPurpose,
                    language = :language,
                    productType = :productType,
                    finAmount = :finAmount,
                    tenure = :tenure,
                    propertyStatus = :propertyStatus,
                    effRate = :effRate,
                    ibanNo = :ibanNo,
                    dependents = :dependents,
                    salary = :salary,
                    employment_status = :employment_status,
                    employer_name = :employer_name,
                    employment_date = :employment_date,
                    national_address = :national_address
                    WHERE user_id = :user_id
                ");
                
                $stmt->execute([
                    'name' => $_POST['name'],
                    'arabic_name' => $_POST['arabic_name'],
                    'email' => $_POST['email'],
                    'phone' => $_POST['phone'],
                    'dob' => $_POST['dob'],
                    'doe' => $_POST['doe'],
                    'finPurpose' => $_POST['finPurpose'],
                    'language' => $_POST['language'],
                    'productType' => $_POST['productType'],
                    'finAmount' => $_POST['finAmount'],
                    'tenure' => $_POST['tenure'],
                    'propertyStatus' => $_POST['propertyStatus'],
                    'effRate' => $_POST['effRate'],
                    'ibanNo' => $_POST['ibanNo'],
                    'dependents' => $_POST['dependents'],
                    'salary' => $_POST['salary'],
                    'employment_status' => $_POST['employment_status'],
                    'employer_name' => $_POST['employer_name'],
                    'employment_date' => $_POST['employment_date'],
                    'national_address' => $_POST['national_address'],
                    'user_id' => $_POST['user_id']
                ]);
                
                if (!empty($_POST['password'])) {
                    $stmt = $conn->prepare("UPDATE Users SET password = :password WHERE user_id = :user_id");
                    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    $stmt->execute(['password' => $password, 'user_id' => $_POST['user_id']]);
                }
                
                $success = "User updated successfully";
            } catch(PDOException $e) {
                $error = "Error updating user: " . $e->getMessage();
            }
            break;
            
        case 'delete':
            try {
                $stmt = $conn->prepare("DELETE FROM Users WHERE user_id = :user_id");
                $stmt->execute(['user_id' => $_POST['user_id']]);
                $success = "User deleted successfully";
            } catch(PDOException $e) {
                $error = "Error deleting user: " . $e->getMessage();
            }
            break;
    }
}

// Fetch users
try {
    $stmt = $conn->query("SELECT * FROM Users ORDER BY created_at DESC");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Error fetching users: " . $e->getMessage();
    $users = [];
}
?>

<div class="users-page">
    <h1>User Management</h1>
    
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <div class="card">
        <h3>Add New User</h3>
        <form id="addUserForm" method="POST" class="user-form">
            <input type="hidden" name="action" value="add">
            
            <div class="form-row">
                <div class="form-group">
                    <label for="national_id">National ID*</label>
                    <input type="text" id="national_id" name="national_id" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="name">Name*</label>
                    <input type="text" id="name" name="name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="arabic_name">Arabic Name*</label>
                    <input type="text" id="arabic_name" name="arabic_name" class="form-control" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="email">Email*</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password*</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone*</label>
                    <input type="tel" id="phone" name="phone" class="form-control" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="dob">Date of Birth*</label>
                    <input type="date" id="dob" name="dob" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="doe">Date of Employment*</label>
                    <input type="date" id="doe" name="doe" class="form-control" required>
                </div>
            </div>
            
            <!-- Additional fields -->
            <div class="form-row">
                <div class="form-group">
                    <label for="finPurpose">Financial Purpose*</label>
                    <input type="text" id="finPurpose" name="finPurpose" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="language">Language*</label>
                    <select id="language" name="language" class="form-control" required>
                        <option value="1">English</option>
                        <option value="2">Arabic</option>
                    </select>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Add User</button>
        </form>
    </div>
    
    <div class="card mt-20">
        <h3>User List</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>National ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['user_id']); ?></td>
                            <td><?php echo htmlspecialchars($user['national_id']); ?></td>
                            <td><?php echo htmlspecialchars($user['name']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['phone']); ?></td>
                            <td><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-user" 
                                        data-user="<?php echo htmlspecialchars(json_encode($user)); ?>">
                                    Edit
                                </button>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-danger" 
                                            onclick="return confirm('Are you sure you want to delete this user?')">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div id="editUserModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Edit User</h2>
        <form id="editUserForm" method="POST">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="user_id" id="edit_user_id">
            
            <!-- Similar fields as add user form -->
            <div class="form-row">
                <div class="form-group">
                    <label for="edit_name">Name*</label>
                    <input type="text" id="edit_name" name="name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_email">Email*</label>
                    <input type="email" id="edit_email" name="email" class="form-control" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="edit_password">New Password (leave blank to keep current)</label>
                    <input type="password" id="edit_password" name="password" class="form-control">
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Update User</button>
        </form>
    </div>
</div>

<style>
.user-form {
    display: grid;
    gap: 20px;
}

.form-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
}

.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    z-index: 1000;
}

.modal-content {
    background-color: #fff;
    margin: 10% auto;
    padding: 20px;
    width: 80%;
    max-width: 600px;
    border-radius: 8px;
    position: relative;
}

.close {
    position: absolute;
    right: 20px;
    top: 10px;
    font-size: 28px;
    cursor: pointer;
}

.table-responsive {
    overflow-x: auto;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle edit user button clicks
    const editButtons = document.querySelectorAll('.edit-user');
    const modal = document.getElementById('editUserModal');
    const closeBtn = modal.querySelector('.close');
    
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const userData = JSON.parse(this.dataset.user);
            
            // Populate form fields
            document.getElementById('edit_user_id').value = userData.user_id;
            document.getElementById('edit_name').value = userData.name;
            document.getElementById('edit_email').value = userData.email;
            
            modal.style.display = 'block';
        });
    });
    
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });
    
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});
</script>
