<?php
if (!checkPermission('sales_admin') && !checkPermission('super_admin')) {
    header('Location: index.php');
    exit();
}

// Handle search filters
$where = "1=1";
$params = [];

if (!empty($_GET['national_id'])) {
    $where .= " AND national_id LIKE :national_id";
    $params[':national_id'] = '%' . $_GET['national_id'] . '%';
}

if (!empty($_GET['status'])) {
    $where .= " AND status = :status";
    $params[':status'] = $_GET['status'];
}

if (!empty($_GET['date_from'])) {
    $where .= " AND status_date >= :date_from";
    $params[':date_from'] = $_GET['date_from'] . ' 00:00:00';
}

if (!empty($_GET['date_to'])) {
    $where .= " AND status_date <= :date_to";
    $params[':date_to'] = $_GET['date_to'] . ' 23:59:59';
}

// Fetch applications
try {
    $query = "SELECT * FROM loan_application_details WHERE {$where} ORDER BY status_date DESC";
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Error fetching applications: " . $e->getMessage();
    $applications = [];
}
?>

<div class="applications-page">
    <h1>Loan Applications</h1>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <div class="card">
        <h3>Search Filters</h3>
        <form method="GET" class="filters-form">
            <input type="hidden" name="page" value="loan-applications">
            
            <div class="form-row">
                <div class="form-group">
                    <label for="national_id">National ID</label>
                    <input type="text" id="national_id" name="national_id" 
                           class="form-control" value="<?php echo $_GET['national_id'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status" class="form-control">
                        <option value="">All</option>
                        <option value="pending" <?php echo ($_GET['status'] ?? '') === 'pending' ? 'selected' : ''; ?>>
                            Pending
                        </option>
                        <option value="approved" <?php echo ($_GET['status'] ?? '') === 'approved' ? 'selected' : ''; ?>>
                            Approved
                        </option>
                        <option value="rejected" <?php echo ($_GET['status'] ?? '') === 'rejected' ? 'selected' : ''; ?>>
                            Rejected
                        </option>
                    </select>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="date_from">Date From</label>
                    <input type="date" id="date_from" name="date_from" 
                           class="form-control" value="<?php echo $_GET['date_from'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="date_to">Date To</label>
                    <input type="date" id="date_to" name="date_to" 
                           class="form-control" value="<?php echo $_GET['date_to'] ?? ''; ?>">
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">Search</button>
            <a href="?page=loan-applications" class="btn btn-secondary">Clear Filters</a>
        </form>
    </div>
    
    <div class="card mt-20">
        <h3>Applications List</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>National ID</th>
                        <th>Loan Amount</th>
                        <th>Purpose</th>
                        <th>Tenure</th>
                        <th>Interest Rate</th>
                        <th>Status</th>
                        <th>Status Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $app): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($app['loan_id']); ?></td>
                            <td><?php echo htmlspecialchars($app['national_id']); ?></td>
                            <td><?php echo number_format($app['loan_amount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($app['loan_purpose']); ?></td>
                            <td><?php echo htmlspecialchars($app['loan_tenure']); ?> months</td>
                            <td><?php echo number_format($app['interest_rate'], 2); ?>%</td>
                            <td>
                                <span class="status-badge status-<?php echo $app['status']; ?>">
                                    <?php echo ucfirst(htmlspecialchars($app['status'])); ?>
                                </span>
                            </td>
                            <td><?php echo date('Y-m-d H:i', strtotime($app['status_date'])); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary view-application" 
                                        data-application="<?php echo htmlspecialchars(json_encode($app)); ?>">
                                    View
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- View Application Modal -->
<div id="viewApplicationModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Loan Application Details</h2>
        <div id="applicationDetails">
            <div class="detail-row">
                <label>Loan ID:</label>
                <span id="view_loan_id"></span>
            </div>
            <div class="detail-row">
                <label>National ID:</label>
                <span id="view_national_id"></span>
            </div>
            <div class="detail-row">
                <label>Loan Amount:</label>
                <span id="view_loan_amount"></span>
            </div>
            <div class="detail-row">
                <label>Purpose:</label>
                <span id="view_loan_purpose"></span>
            </div>
            <div class="detail-row">
                <label>Tenure:</label>
                <span id="view_loan_tenure"></span>
            </div>
            <div class="detail-row">
                <label>Interest Rate:</label>
                <span id="view_interest_rate"></span>
            </div>
            <div class="detail-row">
                <label>Status:</label>
                <span id="view_status"></span>
            </div>
            <div class="detail-row">
                <label>Status Date:</label>
                <span id="view_status_date"></span>
            </div>
            <div class="detail-row">
                <label>Remarks:</label>
                <p id="view_remarks"></p>
            </div>
        </div>
    </div>
</div>

<style>
.filters-form {
    display: grid;
    gap: 20px;
}

.form-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
}

.status-badge {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: bold;
}

.status-pending {
    background-color: #ffeeba;
    color: #856404;
}

.status-approved {
    background-color: #d4edda;
    color: #155724;
}

.status-rejected {
    background-color: #f8d7da;
    color: #721c24;
}

.detail-row {
    margin-bottom: 15px;
}

.detail-row label {
    font-weight: bold;
    display: inline-block;
    width: 120px;
}

#applicationDetails {
    margin-top: 20px;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle view application button clicks
    const viewButtons = document.querySelectorAll('.view-application');
    const modal = document.getElementById('viewApplicationModal');
    const closeBtn = modal.querySelector('.close');
    
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const appData = JSON.parse(this.dataset.application);
            
            // Populate modal with application details
            document.getElementById('view_loan_id').textContent = appData.loan_id;
            document.getElementById('view_national_id').textContent = appData.national_id;
            document.getElementById('view_loan_amount').textContent = 
                new Intl.NumberFormat('en-US', { style: 'currency', currency: 'SAR' })
                    .format(appData.loan_amount);
            document.getElementById('view_loan_purpose').textContent = appData.loan_purpose;
            document.getElementById('view_loan_tenure').textContent = appData.loan_tenure + ' months';
            document.getElementById('view_interest_rate').textContent = appData.interest_rate + '%';
            document.getElementById('view_status').textContent = appData.status;
            document.getElementById('view_status_date').textContent = 
                new Date(appData.status_date).toLocaleString();
            document.getElementById('view_remarks').textContent = appData.remarks || 'No remarks';
            
            modal.style.display = 'block';
        });
    });
    
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });
    
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});
</script>
