<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            flex-shrink: 0;
        }

        .main-content {
            flex-grow: 1;
            padding: 20px;
            background-color: #f5f6fa;
        }

        .sidebar h3 {
            margin-bottom: 20px;
            color: #ecf0f1;
        }

        .nav-link {
            display: block;
            color: #ecf0f1;
            text-decoration: none;
            padding: 10px 0;
            margin-bottom: 5px;
        }

        .nav-link:hover {
            color: #3498db;
        }

        h2 {
            color: #2c3e50;
            margin-bottom: 20px;
        }

        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .stat-card h3 {
            color: #2c3e50;
            margin-bottom: 10px;
        }

        .stat-card p {
            font-size: 24px;
            color: #3498db;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h3>Welcome, <?php echo $_SESSION['name']; ?></h3>
        <nav>
            <a href="pages/users.php" class="nav-link">Manage Users</a>
            <a href="pages/card-applications.php" class="nav-link">Card Applications</a>
            <a href="pages/loan-applications.php" class="nav-link">Loan Applications</a>
            <a href="pages/config.php" class="nav-link">System Config</a>
            <a href="logout.php" class="nav-link">Logout</a>
        </nav>
    </div>
    <div class="main-content">
        <h2>Dashboard Overview</h2>
        <div class="dashboard-stats">
            <?php
            require_once 'db_connect.php';
            
            // Get total card applications
            $cardQuery = "SELECT COUNT(*) as total, 
                         SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
                         FROM card_application_details";
            $cardResult = $conn->query($cardQuery);
            $cardStats = $cardResult->fetch_assoc();

            // Get total loan applications
            $loanQuery = "SELECT COUNT(*) as total,
                         SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
                         FROM loan_application_details";
            $loanResult = $conn->query($loanQuery);
            $loanStats = $loanResult->fetch_assoc();
            ?>
            
            <div class="stat-card">
                <h3>Total Card Applications</h3>
                <p><?php echo $cardStats['total']; ?></p>
                <small>Pending: <?php echo $cardStats['pending']; ?></small>
            </div>
            
            <div class="stat-card">
                <h3>Total Loan Applications</h3>
                <p><?php echo $loanStats['total']; ?></p>
                <small>Pending: <?php echo $loanStats['pending']; ?></small>
            </div>
        </div>
    </div>
</body>
</html>
