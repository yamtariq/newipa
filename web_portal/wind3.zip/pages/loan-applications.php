<?php
session_start();
require_once '../db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Fetch loan applications
$query = "SELECT * FROM loan_application_details ORDER BY status_date DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Loan Applications</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 3% auto;
            padding: 25px;
            border-radius: 12px;
            width: 85%;
            max-width: 800px;
            position: relative;
            max-height: 85vh;
            overflow-y: auto;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .close {
            position: absolute;
            right: 25px;
            top: 15px;
            font-size: 28px;
            font-weight: bold;
            color: #aaa;
            cursor: pointer;
            z-index: 1;
        }

        .close:hover {
            color: #2c3e50;
        }

        .modal-title {
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #3498db;
            color: #2c3e50;
            font-size: 1.5em;
        }

        /* Tabs Styling */
        .tabs {
            display: flex;
            margin-bottom: 20px;
            border-bottom: 2px solid #eee;
            padding-bottom: 0;
        }

        .tab {
            padding: 12px 25px;
            cursor: pointer;
            margin-right: 5px;
            border-radius: 8px 8px 0 0;
            background: #f8f9fa;
            color: #666;
            border: none;
            transition: all 0.3s ease;
        }

        .tab:hover {
            background: #e9ecef;
            color: #2c3e50;
        }

        .tab.active {
            background: #3498db;
            color: white;
            font-weight: 500;
        }

        .tab-content {
            display: none;
            animation: fadeIn 0.5s ease;
        }

        .tab-content.active {
            display: block;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .detail-row {
            display: grid;
            grid-template-columns: 200px 1fr;
            margin-bottom: 12px;
            padding: 10px;
            border-bottom: 1px solid #eee;
            transition: background-color 0.3s ease;
        }

        .detail-row:hover {
            background-color: #f8f9fa;
        }

        .detail-label {
            font-weight: 600;
            color: #2c3e50;
        }

        .detail-value {
            color: #34495e;
        }

        /* Status Badge */
        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 0.9em;
            font-weight: 500;
        }

        .status-pending {
            background-color: #ffeeba;
            color: #856404;
        }

        .status-approved {
            background-color: #d4edda;
            color: #155724;
        }

        .status-rejected {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <?php include '../includes/sidebar.php'; ?>
        <div class="main-content">
            <h2>Loan Applications</h2>
            <div class="search-bar">
                <input type="text" id="search" placeholder="Search by National ID...">
                <select id="statusFilter">
                    <option value="">All Status</option>
                    <option value="pending">Pending</option>
                    <option value="approved">Approved</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Loan ID</th>
                        <th>National ID</th>
                        <th>Amount</th>
                        <th>Purpose</th>
                        <th>Tenure</th>
                        <th>Interest Rate</th>
                        <th>Status</th>
                        <th>Status Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['loan_id']; ?></td>
                        <td><?php echo $row['national_id']; ?></td>
                        <td><?php echo number_format($row['loan_amount'], 2); ?></td>
                        <td><?php echo $row['loan_purpose']; ?></td>
                        <td><?php echo $row['loan_tenure']; ?></td>
                        <td><?php echo $row['interest_rate']; ?>%</td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['status_date']; ?></td>
                        <td>
                            <button class="btn btn-primary" onclick="viewLoanDetails(<?php echo $row['loan_id']; ?>)">View</button>
                            <?php if ($row['status'] === 'pending'): ?>
                            <button class="btn btn-success" onclick="handleStatusUpdate(<?php echo $row['loan_id']; ?>, 'approved', 'loan')">Approve</button>
                            <button class="btn btn-danger" onclick="handleStatusUpdate(<?php echo $row['loan_id']; ?>, 'rejected', 'loan')">Reject</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Loan Details Modal -->
    <div id="loanDetailsModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2 class="modal-title">Loan Application Details</h2>
            
            <div class="tabs">
                <button class="tab active" onclick="switchTab('applicant')">Applicant Information</button>
                <button class="tab" onclick="switchTab('loan')">Loan Details</button>
                <button class="tab" onclick="switchTab('employment')">Employment Information</button>
            </div>

            <div id="applicantTab" class="tab-content active"></div>
            <div id="loanTab" class="tab-content"></div>
            <div id="employmentTab" class="tab-content"></div>
        </div>
    </div>

    <script>
        function viewLoanDetails(loanId) {
            fetch(`../api/get-loan-details.php?id=${loanId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const details = data.details;
                        
                        // Applicant Information Tab
                        const applicantDetails = {
                            'National ID': details.national_id,
                            'Full Name': details.name,
                            'Email Address': details.email,
                            'Phone Number': details.phone
                        };

                        // Loan Details Tab
                        const loanDetails = {
                            'Loan ID': details.loan_id,
                            'Loan Amount': new Intl.NumberFormat('en-US', { style: 'currency', currency: 'SAR' }).format(details.loan_amount),
                            'Purpose': details.loan_purpose,
                            'Tenure (months)': details.loan_tenure,
                            'Interest Rate': details.interest_rate + '%',
                            'Status': `<span class="status-badge status-${details.status}">${details.status.toUpperCase()}</span>`,
                            'Application Date': new Date(details.status_date).toLocaleString(),
                            'Remarks': details.remarks || 'No remarks'
                        };

                        // Employment Information Tab
                        const employmentDetails = {
                            'Employment Status': details.employment_status,
                            'Employer Name': details.employer_name,
                            'Monthly Salary': new Intl.NumberFormat('en-US', { style: 'currency', currency: 'SAR' }).format(details.salary)
                        };

                        // Populate tabs
                        document.getElementById('applicantTab').innerHTML = generateTabContent(applicantDetails);
                        document.getElementById('loanTab').innerHTML = generateTabContent(loanDetails);
                        document.getElementById('employmentTab').innerHTML = generateTabContent(employmentDetails);

                        document.getElementById('loanDetailsModal').style.display = 'block';
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        function generateTabContent(details) {
            let html = '';
            for (const [label, value] of Object.entries(details)) {
                html += `
                    <div class="detail-row">
                        <div class="detail-label">${label}:</div>
                        <div class="detail-value">${value || 'N/A'}</div>
                    </div>
                `;
            }
            return html;
        }

        function switchTab(tabName) {
            // Update tab buttons
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            event.target.classList.add('active');

            // Update tab contents
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            document.getElementById(tabName + 'Tab').classList.add('active');
        }

        function closeModal() {
            document.getElementById('loanDetailsModal').style.display = 'none';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('loanDetailsModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    </script>
    <script src="../assets/js/main.js?v=<?php echo time(); ?>"></script>
</body>
</html>
