<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // Check admin credentials
    if ($email === 'admin@nayifat.com' && $password === 'admin123') {
        $_SESSION['user_id'] = 1;
        $_SESSION['name'] = 'Administrator';
        $_SESSION['role'] = 'admin';
        header("Location: index.php");
        exit();
    } else {
        $error = "Invalid credentials";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Portal Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .login-page {
            background: linear-gradient(135deg, #2c3e50, #3498db);
        }
        .login-container {
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .login-container h2 {
            color: #2c3e50;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .error {
            background: #e74c3c;
            color: white;
            padding: 0.8rem;
            border-radius: 4px;
            margin-bottom: 1rem;
            text-align: center;
        }
    </style>
</head>
<body class="login-page">
    <div class="login-container">
        <h2>Admin Portal Login</h2>
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%;">Login</button>
        </form>
    </div>
</body>
</html>
