<div id="detailsModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <div id="detailsModalContent">
            <!-- Content will be dynamically inserted here -->
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" onclick="closeModal()">Close</button>
        </div>
    </div>
</div>
